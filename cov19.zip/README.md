# GlobalCOVIDVaccineProgress
Visualizing Global COVID-19 Vaccination Progress -- Interactive Choropleth Map with Folium


Data as of: March 2021


Interact with my notebook on Binder! [![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/kendalldyke14/GlobalCOVIDVaccineProgress/HEAD?filepath=covid_vaccination_geo.ipynb)
